# Camunda 7 Labs
## Lab 1: Model and Deploy a Simple Process
- Open Camunda Modeler, create BPMN diagram.
- Add Start Event, User Task, End Event.
- Export BPMN and deploy to engine.
## Lab 2: Add Service Task with Java Delegate
- Add Service Task to your model.
- Implement JavaDelegate, deploy class, and update BPMN to use it.
