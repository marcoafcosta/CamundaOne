# Camunda Academy 7 FAQ
## Q: How do I register for certification?
A: See Camunda Academy website for upcoming exams and registration.
## Q: What is the passing score for Developer certification?
A: Typically 70%; check the latest requirements.
