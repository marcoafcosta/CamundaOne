# CMMN Best Practices (Camunda 7)
- Use CMMN for unstructured, knowledge-driven workflows.
- Clearly document entry/exit criteria and sentries.
- Keep stage and task names business-friendly.
- Use milestones for reporting key progress.
