# DMN Best Practices (Camunda 8)
- Use input expression validation in Modeler.
- Document hit policies for every decision table.
- Use Test Cases in Modeler for coverage.
