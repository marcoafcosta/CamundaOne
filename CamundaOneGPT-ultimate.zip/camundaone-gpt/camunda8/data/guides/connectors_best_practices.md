# Connectors Best Practices (Camunda 8)
- Never hardcode credentials, use secrets.
- Test connectors in dev before promoting to prod.
- Track connector usage with custom Operate filters.
