# Camunda Academy 8 FAQ
## Q: Can I use my Camunda 7 certification for Camunda 8?
A: No, Camunda 8 has separate certification, but prior experience is helpful.
## Q: Are there live instructor-led trainings for Camunda 8?
A: Yes, check Camunda Academy for schedules and formats.
