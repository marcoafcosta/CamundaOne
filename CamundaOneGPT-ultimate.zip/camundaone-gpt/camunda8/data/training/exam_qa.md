# Sample Exam Q&A: Camunda 8 Practitioner
## Q: What is a Zeebe Job Worker in Camunda 8?
A: A Zeebe Job Worker is an external service that polls the engine for tasks of a given type and processes them outside of the workflow engine.
## Q: What is the role of Camunda Operate in Camunda 8?
A: Camunda Operate provides monitoring, search, and visualization for process instances running in Zeebe.
