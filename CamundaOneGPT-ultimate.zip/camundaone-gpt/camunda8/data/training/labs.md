# Camunda 8 Labs
## Lab 1: Model a Cloud-ready Process
- Use Web Modeler to create process.
- Deploy to Camunda Cloud.
- Use Tasklist to complete User Task.
## Lab 2: Add and Test a Connector
- Add REST Connector to BPMN.
- Configure with endpoint and payload.
- Deploy and test with mock service.
