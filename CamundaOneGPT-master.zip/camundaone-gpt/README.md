# CamundaOne GPT Repository Skeleton

See documentation for details.