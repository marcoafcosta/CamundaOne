from fastapi import FastAPI
app = FastAPI()
# Placeholder: Camunda 7 /chat endpoint