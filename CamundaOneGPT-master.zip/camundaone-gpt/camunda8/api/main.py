from fastapi import FastAPI
app = FastAPI()
# Placeholder: Camunda 8 /chat endpoint