# Prompt: Update BPMN Model
"Modify this BPMN XML to add error boundary events..."