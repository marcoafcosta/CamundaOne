# Quiz Master Prompt
"Use the following JSON quiz..."