# Prompt: Create BPMN from Description
"Create a BPMN 2.0 XML model..."