# Prompt: Update DMN Model
"Add a new rule to this DMN table..."