# Prompt: Create CMMN Case Model
"Produce a CMMN XML snippet..."