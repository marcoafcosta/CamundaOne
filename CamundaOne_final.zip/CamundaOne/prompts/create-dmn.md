# Prompt: Create DMN Decision Table
"Generate a DMN 1.3 decision table..."