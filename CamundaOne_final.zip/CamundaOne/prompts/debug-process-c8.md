# Prompt: Debug Camunda 8 Process
"Identify issues in this BPMN execution..."