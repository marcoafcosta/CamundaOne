# Prompt: Review Camunda 8 DMN
"Analyze this DMN and ensure FEEL..."