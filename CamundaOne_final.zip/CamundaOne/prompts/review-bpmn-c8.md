# Prompt: Review Camunda 8 BPMN
"Review this BPMN for Camunda 8..."