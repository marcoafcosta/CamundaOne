# Quiz Guide & JSON Format

Define quizzes in JSON. Example file: `quizzes/camunda8-basics.json`
```json
...```
