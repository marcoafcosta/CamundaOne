# Prompt: Generate DMN Decision Table

"Given this business rule description, generate a DMN decision table with FEEL expressions..."
