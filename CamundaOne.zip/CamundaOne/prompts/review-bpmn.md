# Prompt: Review BPMN for Best Practices

"Review the following BPMN XML and suggest improvements based on best practices in process modeling..."
