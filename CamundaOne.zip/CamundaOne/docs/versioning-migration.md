# Versioning & Instance Migration

- **Process versioning**: Managing multiple deployments
- **Instance migration**: Using the Camunda Migration Tool
- **Best practices**: Backward compatibility, data preservation
