# Camunda 7 vs. Platform 8

| Aspect          | Camunda 7           | Camunda 8 (Zeebe)        |
|-----------------|---------------------|--------------------------|
| Deployment      | Monolithic / Docker | Cloud-native / Kubernetes|
| Persistence     | Relational DB       | Log-based storage        |
