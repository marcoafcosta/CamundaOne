# Observability & Metrics

- **Prometheus exporter**: Zeebe metrics for workflows
- **Distributed tracing**: OpenTelemetry integration
- **Dashboards**: Grafana and Optimize setups
