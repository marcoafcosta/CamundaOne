# Testing & CI/CD

- **Process Test** for Java/Spring
- **GitHub Actions** for model linting & unit tests
