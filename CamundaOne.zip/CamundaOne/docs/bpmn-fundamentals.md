# BPMN 2.0 Fundamentals & Best Practices

- **Elements**: Tasks, Events, Gateways, Subprocesses
- **Patterns**: Sequential, Parallel, Event-based, Compensation
- **Anti-patterns**: Overloaded event subprocesses, deep nesting
