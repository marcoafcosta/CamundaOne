# Platform 8 Architecture & Components

- **Zeebe Broker**: Workflow engine core
- **Operate**: Monitoring UI
- **Tasklist**: Human tasks
- **Identity & Optimize**: Security & reporting
