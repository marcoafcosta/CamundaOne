# Error Handling & Message Correlation

- **Error events**: BPMN boundary/error events & retry strategies
- **Incident management**: Inspecting and resolving errors in Operate
- **Correlation Keys**: Using business keys and message correlation patterns
