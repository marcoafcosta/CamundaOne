# DMN Decision Modeling

- **Decision Tables**: Hit policies, input/output clauses
- **DRDs**: Linking decisions, knowledge sources
- **FEEL**: Expression syntax, built-in functions
