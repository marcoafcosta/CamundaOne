# Integration Patterns & Connectors

- **Built-ins**: Kafka, REST, SOAP
- **External Task**: Java / JavaScript worker samples
