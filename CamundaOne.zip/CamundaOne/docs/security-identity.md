# Security & Identity

- **OAuth2/OIDC**, LDAP
- **RBAC** in REST API
