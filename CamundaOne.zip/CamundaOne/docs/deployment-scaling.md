# Deployment & Scaling

- **Docker Compose** example
- **Helm Charts** for Kubernetes
- **Monitoring**: Prometheus, OpenTelemetry
